package com.gkatzioura.design.structural.proxy;

public interface DataUploadService {

    void upload(String payload);

}
