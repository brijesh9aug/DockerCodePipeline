package com.gkatzioura.design.structural.composite;

public interface MilitaryPersonnel {

    void executeOrder();

}
