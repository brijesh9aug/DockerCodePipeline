package com.gkatzioura.design.creational.abstractfactory;

public interface MovieFactory {
}
