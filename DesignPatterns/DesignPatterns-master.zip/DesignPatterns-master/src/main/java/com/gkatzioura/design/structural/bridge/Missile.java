package com.gkatzioura.design.structural.bridge;

public interface Missile {

    void explode();

}
