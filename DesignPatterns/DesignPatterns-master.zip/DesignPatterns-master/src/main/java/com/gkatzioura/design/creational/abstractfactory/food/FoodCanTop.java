package com.gkatzioura.design.creational.abstractfactory.food;

import com.gkatzioura.design.creational.abstractfactory.CanTop;

public class FoodCanTop implements CanTop {

    public void open() {

    }
}
