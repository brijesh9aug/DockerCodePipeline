package com.gkatzioura.design.creational.abstractfactory;

public interface CanBody {

    void fill();

}
