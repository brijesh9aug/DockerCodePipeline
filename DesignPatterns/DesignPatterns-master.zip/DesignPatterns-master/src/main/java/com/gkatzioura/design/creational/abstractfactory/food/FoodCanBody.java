package com.gkatzioura.design.creational.abstractfactory.food;

import com.gkatzioura.design.creational.abstractfactory.CanBody;

public class FoodCanBody implements CanBody {

    public void fill() {

    }
}
