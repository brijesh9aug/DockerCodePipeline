package com.gkatzioura.design.behavioural.state;

public interface GreetingState {

    String create();

}
