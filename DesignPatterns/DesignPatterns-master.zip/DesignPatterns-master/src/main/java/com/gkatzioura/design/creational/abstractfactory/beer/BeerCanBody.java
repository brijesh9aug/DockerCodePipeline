package com.gkatzioura.design.creational.abstractfactory.beer;

import com.gkatzioura.design.creational.abstractfactory.CanBody;

public class BeerCanBody implements CanBody {

    public void fill() {

    }
}
