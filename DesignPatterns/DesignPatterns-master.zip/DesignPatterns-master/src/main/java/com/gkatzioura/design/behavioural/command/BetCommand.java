package com.gkatzioura.design.behavioural.command;

public interface BetCommand {

    void applyTo(BetBook betBook);

}
