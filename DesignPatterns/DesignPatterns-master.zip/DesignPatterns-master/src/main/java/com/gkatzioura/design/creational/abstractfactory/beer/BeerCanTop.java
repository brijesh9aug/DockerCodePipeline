package com.gkatzioura.design.creational.abstractfactory.beer;

import com.gkatzioura.design.creational.abstractfactory.CanTop;

public class BeerCanTop implements CanTop {

    public void open() {

    }
}
