package com.gkatzioura.design.structural.composite;

public interface Officer {

    void assignOrder(MilitaryPersonnel militaryPersonnel);

}
