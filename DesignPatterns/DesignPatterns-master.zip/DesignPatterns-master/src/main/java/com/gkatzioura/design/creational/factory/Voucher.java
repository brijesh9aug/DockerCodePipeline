package com.gkatzioura.design.creational.factory;

public interface Voucher {

    public String code();

    public String htmlMessage();
}
