package com.gkatzioura.design.creational.abstractfactory;

public interface CanTop {

    void open();

}
