package com.gkatzioura.design.behavioural.mediator;

public class FinancialEntity {

    public boolean sell(Order order) {

        /**
         * Supposing the sale was successful return true
         */
        return true;
    }

}
