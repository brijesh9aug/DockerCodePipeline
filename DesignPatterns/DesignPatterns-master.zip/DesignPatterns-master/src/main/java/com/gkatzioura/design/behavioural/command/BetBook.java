package com.gkatzioura.design.behavioural.command;

public class BetBook {

    public void addBacking(String match, Integer amount) {
        /**
         * Add the backing to the book
         */
    }

}
