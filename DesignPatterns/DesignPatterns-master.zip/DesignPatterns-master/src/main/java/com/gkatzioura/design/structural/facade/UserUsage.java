package com.gkatzioura.design.structural.facade;

public class UserUsage {
}
