package com.gkatzioura.design.structural.facade;

public class TimeInformation {
}
