package com.gkatzioura.design.structural.bridge;

public interface Igniter {

    void ignite();
}
