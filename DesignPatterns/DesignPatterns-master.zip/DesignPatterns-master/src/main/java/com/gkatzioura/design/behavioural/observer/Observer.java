package com.gkatzioura.design.behavioural.observer;

public interface Observer {

    void update(SensorData sensorData);

}
